package com.example.studentsecurity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class StudentAttendance extends AppCompatActivity {
    public String user;
    public String IP="10.0.2.2";
    public WebView web;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_attendance);
        Intent intent = getIntent();
        user = intent.getStringExtra("user");
        web=findViewById(R.id.attendance_web);
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebClient());
        web.setBackgroundColor(Color.TRANSPARENT);
        web.loadUrl("http://"+IP+":8000/app/child_attendance/?us="+user);
    }

    private class WebClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(StudentAttendance.this,MainActivity.class);
        i.putExtra("user",user);
        startActivity(i);
        finish();
    }
}