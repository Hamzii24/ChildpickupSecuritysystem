package com.example.studentsecurity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Login extends AppCompatActivity {
    public TextView ID;
    public TextView Pass;
    public String IP="10.0.2.2";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ID=findViewById(R.id.email);
        Pass=findViewById(R.id.password);
    }

    public void login_check(String id,String pass){
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://"+IP+":8000/app/login/?us="+id+"&p="+pass;
        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        //Toast.makeText(getApplicationContext(),response,Toast.LENGTH_SHORT).show();
                        if(response.contains("true")){
                            //Login Available
                            Intent i = new Intent(Login.this,MainActivity.class);
                            i.putExtra("user",id);
                            startActivity(i);
                            finish();
                        }
                        else{
                            Toast.makeText(getApplicationContext(),"Can't find User. Login Failed",Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Didn't Work",Toast.LENGTH_SHORT).show();
            }
        });
        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    public void Register(View view){
        Intent i = new Intent(Login.this,Register.class);
        startActivity(i);
        finish();
    }

    public void login(View view){
        String user_id=ID.getText().toString();
        String user_pass=Pass.getText().toString();
        login_check(user_id,user_pass);
    }
}