package com.example.studentsecurity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Register extends AppCompatActivity {
    public TextView user,pass,email,con_pass,notify;
    public String IP="10.0.2.2";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        user=findViewById(R.id.userID);
        pass=findViewById(R.id.pass);
        con_pass=findViewById(R.id.confirm_pass);
        email=findViewById(R.id.editTextMail);
        notify=findViewById(R.id.reg_response);
    }

    public void RegisterPressed(View view){
        if(pass.getText().toString().equals(con_pass.getText().toString())) {
        }
        else{
            notify.setText("Password and Confirm Password do not match!");
            return ;
        }
        String id=user.getText().toString();
        String password=pass.getText().toString();
        String _email=email.getText().toString();
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://"+IP+":8000/app/register/?us="+id+"&p="+password+"&no="+_email;
        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        Toast.makeText(getApplicationContext(),response,Toast.LENGTH_SHORT).show();
                        if(response.contains("Successfully")){
                            //Login Available
                            Intent i = new Intent(Register.this,Login.class);
                            startActivity(i);
                            finish();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),"Network Error",Toast.LENGTH_SHORT).show();
            }
        });
        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(Register.this,Login.class);
        startActivity(i);
        finish();
    }
}