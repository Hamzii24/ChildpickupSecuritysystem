package com.example.studentsecurity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class RegisteredChildrens extends AppCompatActivity {
    public WebView web;
    String IP="10.0.2.2";
    String user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered_childrens);
        Intent intent = getIntent();
        user = intent.getStringExtra("user");
        web=findViewById(R.id.registered_child);
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebClient());
        web.setBackgroundColor(Color.TRANSPARENT);
        web.loadUrl("http://"+IP+":8000/app/assosiatechilds/?us="+user);
    }

    private class WebClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(RegisteredChildrens.this,MainActivity.class);
        i.putExtra("user",user);
        startActivity(i);
        finish();
    }
}