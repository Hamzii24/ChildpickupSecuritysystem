import React from 'react'

export default function Header() {
  return (
    <div className='container'>
    <br/>
    <nav class="navbar navbar-light bg-light justify-content-between">
        <a class="navbar-brand">ADMIN DASHBOARD</a>
        <form class="form-inline">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"/>   
        </form>
    </nav>
    </div>
  )
}
