import React from 'react'
import { useState,useEffect } from 'react'
import axios from 'axios'
export default function Student() {
    const [State, set] = useState([])
    useEffect(()=>{
        async function getAllData(){
            try {
                const DATA= await axios.get("http://127.0.0.1:8000/students/")
                console.log(DATA.data)
                set(DATA.data)
            } catch (error) {
                console.log(error)
            }
        }
        getAllData()
    },[])
  return (
    <div className='container'>
        <br/>
        <div className='row'>
        <div className='col-4'></div>
            <div className='col-4'>
            <h1 >Students</h1>
                <br/>
                <br/>
                <a href="http://127.0.0.1:8000/admin/svs_app/studentclass/add/"><button className='btn btn-success' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white"}}>Add Student </button></a>
            </div>
            <div className='col-4'></div>
        </div>
        <br/>
        <br/>
        <div className='row'>
            <div className='col-4'></div>
            <div className='col-6'>
                <h3>Student Details</h3>
            </div>
            <div className='col-2'>
            <form class="form-inline">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"/>   
            </form>
            </div>
        </div>
        <div className='row'>
            <div className='col-4'></div>
            <div className='col-8'>
                <br/>
                <br/>
                <table className='table'>
                <thead>
                    <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Roll No</th>
                    <th scope="col">Guardian</th>
                    <th scope="col">Class</th>
                    <th scope="col">Sections</th>
                    <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        State.map((Data,i)=>{
                            return (
                                <tr key={i}>
                                    <td >{Data.student_name}</td>
                                    <td >{Data.RollNo}</td>
                                    <td >{Data.guard_name}</td>
                                    <td >{Data.Class}</td>
                                    <td >{Data.Section}</td>
                                    <td><a href={"http://127.0.0.1:8000/admin/svs_app/studentclass/"+Data.id+"/change/"}><button className='btn btn-info' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white"}} >Edit</button></a></td>
                                </tr>
                            )

                        })
                    }

                </tbody>
                </table>
            </div>
        </div>
    </div>
  )
}
