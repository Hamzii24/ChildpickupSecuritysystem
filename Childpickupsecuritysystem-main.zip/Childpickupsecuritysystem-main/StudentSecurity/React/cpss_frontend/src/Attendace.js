import React from 'react'
import axios from 'axios'
import { useState,useEffect } from 'react'
import Student from './Student'
export default function Attendace() {
    const [attendanceState, setAttendance] = useState([])
    useEffect(()=>{
        async function getAllAttendance(){
            try {
                const attendance= await axios.get("http://127.0.0.1:8000/attendance/")
                console.log(attendance.data)
                setAttendance(attendance.data)
            } catch (error) {
                console.log(error)
            }
        }
        getAllAttendance()
    },[])
  return (
    <div className='container'>
        
        <br/>
        <div className='row'>
        <div className='col-4'></div>
            <div className='col-4'>
            <h1 >ATTENDANCE</h1>
                <br/>
                <br/>
                <a href="http://127.0.0.1:8000/admin/svs_app/attendance/add/"><button className='btn btn-success' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white"}}>Add Attendance </button></a>
            </div>
            <div className='col-4'></div>
        </div>
        <br/>
        <br/>
        <div className='row'>
            <div className='col-4'></div>
            <div className='col-6'>
                <h3>Attendance Detail</h3>
            </div>
            <div className='col-2'>
            <form class="form-inline">
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"/>   
            </form>
            </div>
        </div>
        <div className='row'>
            <div className='col-4'></div>
            <div className='col-8'>
                <br/>
                <br/>
                <table className='table'>
                <thead>
                    <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Class</th>
                    <th scope="col">Section</th>
                    <th scope="col">Date/Time</th>
                    <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        attendanceState.map((data,i)=>{
                            return (
                                <tr key={i}>
                                    <td >{data.Name}</td>
                                    <td >{data.Class}</td>
                                    <td >{data.Section}</td>
                                    <td >{data.date}</td>
                                    <td >Present</td>
                                </tr>
                            )

                        })
                    }

                </tbody>
                </table>
            </div>
        </div>
    </div>
  )
}
