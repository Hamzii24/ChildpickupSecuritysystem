import React from 'react'
import { Link } from 'react-router-dom'
export default function SideBar(props) {
  return (
    <div className='container'>
    <div class="sidebar">
        { console.log() }
        <Link class={props.dashboard} to="/dashboard">DASHBOARD</Link>
        <Link class={props.teacher} to="/teacher">TEACHERS</Link>
        <Link class={props.student} to="/student">STUDENTS</Link>
        <Link class={props.guardian} to="/guardian">GUARDIANS</Link>
        <Link class={props.attendance} to="/attendance">ATTENDANCE</Link>
        <Link  class={props.notification} to="/notification">NOTIFICATONS</Link>
        <a href="http://127.0.0.1:8000/accounts/logout"  >LOGOUT</a>
    </div>
    </div>
  )
}
