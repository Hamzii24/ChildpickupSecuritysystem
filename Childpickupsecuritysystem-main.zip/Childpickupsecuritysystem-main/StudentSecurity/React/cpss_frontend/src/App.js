import './App.css';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from "react-router-dom";
import Dashboard from './Dashboard';
import Header from './Header';
import SideBar from './SideBar'
import Teacher from './Teacher';
import Student from './Student'
import Guardian from './Guardian'
import Attendance from './Attendace'
import Notification from './Notification';

function App() {
  return (
    <Router>
    <>
    <Header/>
    <Routes> 
        <Route  path="/guardian" element={<><SideBar guardian="active" /><Guardian/> </>}/>
        <Route  path="/teacher" element={<> <SideBar teacher="active" /><Teacher/> </>}/>
        <Route  path="/student" element={<> <SideBar student="active" /> <Student/> </>}/>
        <Route  path="/attendance" element={<> <SideBar attendance="active" /> <Attendance/> </>}/>
        <Route  path="/dashboard" element={<> <SideBar dashboard="active" /> <Dashboard/> </>}/>
        <Route  path="/notification" element={<> <SideBar notification="active" /> <Notification/> </>}/>
      </Routes> 
    </>
    </Router>
  );
}

export default App;
