import React from 'react'
import axios from 'axios'
import { useState,useEffect } from 'react'
export default function Notification() {
    const [State, set] = useState([])
    useEffect(()=>{
        async function getAllData(){
            try {
                const DATA= await axios.get("http://127.0.0.1:8000/notifications/")
                console.log(DATA.data)
                set(DATA.data)
            } catch (error) {
                console.log(error)
            }
        }
        getAllData()
    },[])
  return (
    <div className='container'>
        <br/>
        <div className='row'>
        <div className='col-4'></div>
            <div className='col-4'>
            <h1 >Notification</h1>
                <br/>
                <br/>
                <a href="http://127.0.0.1:8000/admin/svs_app/attendance/add/"><button className='btn btn-success' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white"}}>Add Notifications </button></a>
            </div>
            <div className='col-4'></div>
        </div>
        <br/>
        <br/>
        <div className='row'>
            <div className='col-4'></div>
            <div className='col-6'>
                <h3>Notification History</h3>
            </div>
            <div className='col-2'>
           
            </div>
        </div>
        <div className='row'>
            <div className='col-4'></div>
            <div className='col-8'>
                <br/>
                <br/>
                <table className='table'>
                <thead>
                    <tr>
                    <th scope="col">Date</th>
                    <th scope="col">Notification</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        State.map((Data,i)=>{
                            return (
                                <tr key={i}>
                                    <td >{Data.date}</td>
                                    <td >{Data.notification}</td>
                                </tr>
                            )

                        })
                    }
                </tbody>
                </table>
            </div>
        </div>
    </div>
  )
}
