import React from 'react'
import CardBootStrap from './CardBootStrap'
import axios from 'axios'
import { useState,useEffect } from 'react'

export default function Dashboard() {
    const [State, setState] = useState([])
    useEffect(()=>{
        async function getAllData(){
            try {
                const DATA= await axios.get("http://127.0.0.1:8000/dashboard/")
                console.log(DATA.data)
                setState(DATA.data)
                console.log(State)
            } catch (error) {
                console.log(error)
            }
        }
        getAllData()
    },[])
  return (
    <div className='container'>
        <br/>
        <center><h1 >DASHBOARD</h1></center>
        <br/>
        <br/>
        <div className='row'>
            <div className='col-3'></div>
            <div className='col-3'><h4>Open Camera</h4></div>
            <div className='col-2'>
                <a href="http://127.0.0.1:8000/app/guardian_camera/"><button className='btn btn-info' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white",width:"100%"}}>Guardian Camera </button></a>
            </div>
            <div className='col-2'>
                <a href="http://127.0.0.1:8000/app/student_attendance/"><button className='btn btn-info' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white",width:"100%"}}>Attendance Camera </button></a>
            </div>
            <div className='col-2'>
                <a href="http://127.0.0.1:8000/app/exit_camera/"><button className='btn btn-info' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white",width:"100%"}}>Exit Camera </button></a>
            </div>
        </div>
        <br/>
        <br/>
        <div className='row'>
            <div className='col-3'></div>
            <div className='col-3'><h4>Add Users</h4></div>
            <div className='col-2'>
                <a href="http://127.0.0.1:8000/admin/svs_app/teacher/add/"><button className='btn btn-info' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white",width:"100%"}}>ADD Teacher</button></a>
            </div>
            <div className='col-2'>
                <a href="http://127.0.0.1:8000/admin/svs_app/studentclass/add/"><button className='btn btn-info' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white",width:"100%"}}>ADD Student </button></a>
            </div>
            <div className='col-2'>
                <a href="http://127.0.0.1:8000/admin/svs_app/guardian/add/"><button className='btn btn-info' style={{backgroundColor: "rgb(65, 118, 144)",border:"rgb(65, 118, 144)",color:"white",width:"100%"}}>ADD Guardian</button></a>
            </div>
        </div>
        <br/>
        <br/>
        
    </div>
  )
}
