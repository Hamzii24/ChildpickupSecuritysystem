import React from 'react'
import { propTypes } from 'prop-types'

export default function CardBootStrap(props) {
  return (
    <div className="card" style={{width: "18rem"}}>
        <div className="card-body">
            <h5 className="card-title">{props.cardName}</h5>
            <p className="card-text">{props.cardText}</p>
        </div>
    </div>
  )
}

