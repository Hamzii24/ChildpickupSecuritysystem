from django.urls import path
from . import views
urlpatterns = [
    path('addNotification/',views.addNotification,name='add_notification'),
    path('addTeacher/',views.addTeacher,name='add_teacher'),
    path('set_attendance/',views.set_attendance,name='Get Student Attendance'),
    path('check_attendance/',views.check_attendance,name='Check Attendance'),
    path('live_attendance',views.livefe,name="Live Cam Feed"),
    path('live_feed',views.liveguardfeed,name="Live Feed"),
    path('live_exit_camera/',views.liveExitfeed,name='Live_Exist_feed'),
    path('student_attendance/',views.StudentAttendanceView,name='Student_Attendance_View'),
    path('guardian_camera/',views.GuardianCameraView,name='Guardian_Camera_View'),
    path('exit_camera/',views.ExitCameraView,name='Exist_Camera_View'),
    path('check_guard/',views.check_guard_arrival,name='Check_Guard_Arrival'),
    path('add_arrived/',views.add_arrived,name='Add_Guard_Arrival'),
    path('student_exit/',views.student_arrived,name='Student_Exit'),
    path('waiting_room/',views.waiting_room,name='Guard_Waiting_Room'),
    path('waiting_room_mob/',views.waiting_room_mob,name='Waiting_Room_Mob'),
    path('show_notification/',views.ShowNotifications,name='Showing_Notifications'),
    path('login/',views.ParentLogin,name='Parent_Login'),
    path('register/',views.register,name='Parent_Register'),
    path('assosiatechilds/',views.AssosiateChilds,name='Parent_Assosiate_Childs'),
    path('child_attendance/',views.ParentChildAttendance,name='Parent_Assosiate_Childs_attendance'),   
]
