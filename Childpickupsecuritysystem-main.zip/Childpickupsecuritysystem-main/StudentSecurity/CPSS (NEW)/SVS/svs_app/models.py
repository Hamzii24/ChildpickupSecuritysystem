from django.db import models


class User(models.Model):
    userType=[('Teacher','Teacher'),
    ('Student','Student'),
    ('Guardian','Guardian'),
    ]
    Name=models.CharField(max_length=50,unique=True)
    Email=models.EmailField(unique=True)
    UserType=models.CharField(choices=userType,max_length=20,default='Student')
    Password=models.CharField(max_length=50)
    def __str__(self):
        return self.Name


class Guardian(models.Model):
    User=models.ForeignKey(User,on_delete=models.CASCADE)
    phone=models.CharField(max_length=20)
    image = models.ImageField(upload_to='Guardians',blank=True)
    def __str__(self):
        return self.User.Name


class StudentClass(models.Model):
    User=models.ForeignKey(User,on_delete=models.CASCADE)
    Class=models.CharField(max_length=20)
    image = models.ImageField(upload_to='Users',blank=True)
    RollNo=models.IntegerField()
    Guard=models.ForeignKey(Guardian,on_delete=models.CASCADE)
    Section=models.CharField(max_length=10)
    def __str__(self):
        return self.User.Name


class Teacher(models.Model):
    User=models.ForeignKey(User,on_delete=models.CASCADE)
    Address=models.CharField(max_length=300)
    Class=models.CharField(max_length=20)
    def __str__(self):
        return self.User.Name


class Attendance(models.Model):
    date=models.DateTimeField(auto_now_add=True)
    student=models.ForeignKey(StudentClass,on_delete=models.CASCADE)
    attendance=models.BooleanField(default=False)
    def __str__(self):
        return self.student.User.Name


class Notification(models.Model):
    date=models.DateTimeField(auto_now_add=True)
    notification=models.CharField(max_length=300)
    seen=models.BooleanField(default=False)
    def __str__(self):
        return self.notification


class StudentGuard(models.Model):
    student=models.ForeignKey(StudentClass,on_delete=models.CASCADE)
    guard=models.ForeignKey(Guardian,on_delete=models.CASCADE)


class GuardArrived(models.Model):
    guard=models.ForeignKey(Guardian,on_delete=models.CASCADE)
    date=models.DateTimeField(auto_now_add=True)


class Parent(models.Model):
    Name=models.CharField(max_length=50)
    Email=models.EmailField(unique=True)
    Password=models.CharField(max_length=50)
    def __str__(self):
        return self.Name

class ParentAssosiate(models.Model):
    parent=models.ForeignKey(Parent,on_delete=models.CASCADE)
    child=models.ForeignKey(StudentClass,on_delete=models.CASCADE)