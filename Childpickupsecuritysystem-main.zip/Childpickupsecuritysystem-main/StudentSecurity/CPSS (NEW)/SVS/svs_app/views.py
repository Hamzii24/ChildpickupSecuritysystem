from django.http import HttpResponse,HttpResponseRedirect,StreamingHttpResponse
from django.contrib import messages
from django.shortcuts import render,get_object_or_404
from django.contrib.auth.decorators import login_required
from rest_framework.views import APIView
from django.views.decorators import gzip
from rest_framework.response import Response
from .models import *
from .serialize import *
from .forms import *
import json
import face_recognition
import cv2
import threading
from datetime import datetime,timedelta
import requests
import numpy as np
import os



#Face Recog Statics
known_student_encodings = [

]
known_student_names = [
    
]

known_guard_encodings = [

]
known_guard_names = [
    
]

for (roots,dirs,files) in os.walk('media/Guardians',topdown=True):
    #print(roots)
    #print(dirs)
    #print(files)
    for images in files:
        if images[-4:]=='.jpg':
            name=images.replace('.jpg','')
            print(name)
            # Load a third sample picture and learn how to recognize it.
            data_image = face_recognition.load_image_file("media/Guardians/"+images)
            data_face_encoding = face_recognition.face_encodings(data_image)[0]
            known_guard_encodings.append(data_face_encoding)
            known_guard_names.append(name)


for (roots,dirs,files) in os.walk('media/Users',topdown=True):
    #print(roots)
    #print(dirs)
    #print(files)
    for images in files:
        if images[-4:]=='.jpg':
            rollno=images.replace('.jpg','')
            print(rollno)
            # Load a third sample picture and learn how to recognize it.
            data_image = face_recognition.load_image_file("media/Users/"+images)
            data_face_encoding = face_recognition.face_encodings(data_image)[0]
            known_student_encodings.append(data_face_encoding)
            known_student_names.append(rollno)

# Initialize some variables
face_locations = []
face_encodings = []
face_names = []


class VideoCamera(object):
    def __init__(self,attendance):
        self.attendance=attendance
        if self.attendance:
            self.video = cv2.VideoCapture(0)#Attendance
        else:
            self.video = cv2.VideoCapture(0)#Exit Cam
        (self.grabbed, self.frame) = self.video.read()
        threading.Thread(target=self.update, args=()).start()

    def __del__(self):
        self.video.release()

    def get_frame(self):
        process_this_frame = True
        image = self.frame
        # Resize frame of video to 1/4 size for faster face recognition processing
        small_frame = cv2.resize(image, (0, 0), fx=0.25, fy=0.25)

        # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
        rgb_small_frame = small_frame[:, :, ::-1]

        # Only process every other frame of video to save time
        if process_this_frame:
            # Find all the faces and face encodings in the current frame of video
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

            face_names = []
            for face_encoding in face_encodings:
                # See if the face is a match for the known face(s)
                matches = face_recognition.compare_faces(known_student_encodings, face_encoding)
                name = "Unknown"

                # # If a match was found in known_face_encodings, just use the first one.
                # if True in matches:
                #     first_match_index = matches.index(True)
                #     name = known_face_names[first_match_index]

                # Or instead, use the known face with the smallest distance to the new face
                face_distances = face_recognition.face_distance(known_student_encodings, face_encoding)
                best_match_index = np.argmin(face_distances)
                if matches[best_match_index]:
                    name = known_student_names[best_match_index]
                    if self.attendance:
                        if requests.get('http://127.0.0.1:8000/app/check_attendance/?q='+name).text == 'already':
                            name='Marked: '+ name
                            print('Already Attendance Marked')
                        else:
                            addNotification("Student with roll no "+name+" arrived at School")
                            requests.get('http://127.0.0.1:8000/app/set_attendance/?q='+name)
                if self.attendance:
                    face_names.append(name)
                else:
                    addNotification("Student with roll no "+name+" has exited School")
                    requests.get('http://127.0.0.1:8000/app/student_exit/?q='+name)
                    face_names.append(name+" Exit")

        process_this_frame = not process_this_frame


        # Display the results
        for (top, right, bottom, left), name in zip(face_locations, face_names):
            # Scale back up face locations since the frame we detected in was scaled to 1/4 size
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            # Draw a box around the face
            cv2.rectangle(image, (left, top), (right, bottom), (0, 0, 255), 2)

            # Draw a label with a name below the face
            cv2.rectangle(image, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(image, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

        _, jpeg = cv2.imencode('.jpg', image)
        return jpeg.tobytes()

    def update(self):
        while True:
            (self.grabbed, self.frame) = self.video.read()

class GuardCamera(object):
    def __init__(self,attendance):
        self.video = cv2.VideoCapture(0)#change camera number for Guardian Cam
        self.attendance=attendance
        (self.grabbed, self.frame) = self.video.read()
        threading.Thread(target=self.update, args=()).start()

    def __del__(self):
        self.video.release()

    def get_frame(self):
        process_this_frame = True
        image = self.frame
        # Resize frame of video to 1/4 size for faster face recognition processing
        small_frame = cv2.resize(image, (0, 0), fx=0.25, fy=0.25)

        # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
        rgb_small_frame = small_frame[:, :, ::-1]

        # Only process every other frame of video to save time
        if process_this_frame:
            # Find all the faces and face encodings in the current frame of video
            face_locations = face_recognition.face_locations(rgb_small_frame)
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

            face_names = []
            for face_encoding in face_encodings:
                # See if the face is a match for the known face(s)
                matches = face_recognition.compare_faces(known_guard_encodings, face_encoding)
                name = "Unknown"

                # # If a match was found in known_face_encodings, just use the first one.
                # if True in matches:
                #     first_match_index = matches.index(True)
                #     name = known_face_names[first_match_index]

                # Or instead, use the known face with the smallest distance to the new face
                face_distances = face_recognition.face_distance(known_guard_encodings, face_encoding)
                best_match_index = np.argmin(face_distances)
                if matches[best_match_index]:
                    name = known_guard_names[best_match_index]
                    if self.attendance:
                        if requests.get('http://127.0.0.1:8000/app/check_guard/?q='+name).text == 'already':
                            name=name+' Arrived '
                            print('Already Arrived')
                        else:
                            requests.get('http://127.0.0.1:8000/app/add_arrived/?q='+name)
                if self.attendance:
                    face_names.append(name)
                else:
                    face_names.append("Guardian Detected")

        process_this_frame = not process_this_frame


        # Display the results
        for (top, right, bottom, left), name in zip(face_locations, face_names):
            # Scale back up face locations since the frame we detected in was scaled to 1/4 size
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            # Draw a box around the face
            cv2.rectangle(image, (left, top), (right, bottom), (0, 0, 255), 2)

            # Draw a label with a name below the face
            cv2.rectangle(image, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
            font = cv2.FONT_HERSHEY_DUPLEX
            cv2.putText(image, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)

        _, jpeg = cv2.imencode('.jpg', image)
        return jpeg.tobytes()

    def update(self):
        while True:
            (self.grabbed, self.frame) = self.video.read()

def gen(camera):
    while True:
        frame = camera.get_frame()
        yield(b'--frame\r\n'
              b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')

@gzip.gzip_page
def livefe(request):
    try:
        cam = VideoCamera(True)
        return StreamingHttpResponse(gen(cam), content_type="multipart/x-mixed-replace;boundary=frame")
    except:  # This is bad! replace it with proper handling
        pass

@gzip.gzip_page
def liveExitfeed(request):
    try:
        cam = VideoCamera(False)
        return StreamingHttpResponse(gen(cam), content_type="multipart/x-mixed-replace;boundary=frame")
    except:  # This is bad! replace it with proper handling
        pass

@gzip.gzip_page
def liveguardfeed(request):
    try:
        cam = GuardCamera(True)
        return StreamingHttpResponse(gen(cam), content_type="multipart/x-mixed-replace;boundary=frame")
    except:  # This is bad! replace it with proper handling
        pass

def StudentAttendanceView(request):
    return render(request,'student_attendance.html')

def GuardianCameraView(request):
    return render(request,'guardian_camera.html')

def ExitCameraView(request):
    return render(request,'exit_camera.html')

def addTeacher(request):
    if request.method == "POST":
        form = TeacherForm(request.POST, request.FILES or None)
        PostData=request.POST.copy()
        if form.is_valid():
            print(PostData)
            addUser(PostData,'Teacher')
            teacher=User.objects.get(Email=PostData['Email'])
            DB=Teacher()
            DB.Address=PostData['Address']
            DB.Class=PostData['Class']
            DB.User=teacher
            DB.save()
            messages.success(request, 'Successfully created your listing.', fail_silently=True)
        else:
            messages.error(request, 'Invalid Listing!', fail_silently=True)
            return HttpResponseRedirect("http://localhost:3000/teacher")
        return HttpResponseRedirect("http://localhost:3000/teacher")
    form = TeacherForm()
    context = {
        'form': form,
    }
    return render(request, "Add.html", context)

def addNotification(request):
    if request.method == "POST":
        form = NotificationForm(request.POST, request.FILES or None)
        PostData=request.POST.copy()
        if form.is_valid():
            newNotification = form.save(commit=False)
            newNotification.save()
            messages.success(request, 'Successfully created your listing.', fail_silently=True)
        else:
            messages.error(request, 'Invalid Listing!', fail_silently=True)
            return HttpResponseRedirect("http://localhost:3000/notification")
        return HttpResponseRedirect("http://localhost:3000/notification")
    form = NotificationForm()
    context = {
        'form': form,
    }
    return render(request, "form.html", context)

def addUser(PostData,Status):
    DB=User()
    DB.Name=PostData['Name']
    DB.Email=PostData['Email']
    DB.Password=PostData['Password']
    DB.UserType=Status
    DB.save()

def set_attendance(request):
    id=request.GET.get('q')
    user=StudentClass.objects.get(RollNo=id)
    db=Attendance()
    db.attendance=True
    db.student=user
    db.save()
    return HttpResponse(id)

def check_attendance(request):
    _id=request.GET.get('q')
    _student=StudentClass.objects.get(RollNo=_id)
    attendance=Attendance.objects.filter(student=_student).order_by('-date')[0]
    date=attendance.date + timedelta(hours=5)
    if datetime.now().strftime('%B %d %Y') == date.strftime('%B %d %Y'):
        print('Already Attendance')
        return HttpResponse('already')
    print(datetime.now().strftime('%B %d %Y'))
    return HttpResponse(attendance.date.strftime('%B %d %Y'))

def check_guard_arrival(request):
    _name=request.GET.get('q')
    _user=User.objects.get(Name=_name)
    _guard=Guardian.objects.get(User=_user)
    try:
        arrived=GuardArrived.objects.filter(guard=_guard).order_by('-date')[0]
        print(datetime.now().strftime('%B %d %Y'))
        print(arrived.date.strftime('%B %d %Y'))
        date=arrived.date + timedelta(hours=5)
        if datetime.now().strftime('%B %d %Y') == date.strftime('%B %d %Y'):
            print('Already Arrived')
            return HttpResponse('already')
    except:
        print(datetime.now().strftime('%B %d %Y'))
        return HttpResponse("Not Arrrived Yet")

def add_arrived(request):
    _name=request.GET.get('q')
    _user=User.objects.get(Name=_name)
    guard=Guardian.objects.get(User=_user)
    db=GuardArrived()
    db.guard=guard
    db.save()
    return HttpResponse(_name)

def student_arrived(request):
    _id=request.GET.get('q')
    try:
        _student=StudentClass.objects.get(RollNo=_id)
        _StudentGuard=StudentGuard.objects.get(student=_student)
        _Object=GuardArrived.objects.get(guard=_StudentGuard.guard)
        _Object.delete()
        return HttpResponse("Deleted")
    except:
        return HttpResponse("No DataSet Found")

def waiting_room(request):
    Arrived=GuardArrived.objects.all().order_by('-date')
    Data=StudentGuard.objects.all()
    context={'Data':Data,'Arrived':Arrived}
    return render(request,'WaitingRoom.html',context)

def waiting_room_mob(request):
    Arrived=GuardArrived.objects.all().order_by('-date')
    Data=StudentGuard.objects.all()
    context={'Data':Data,'Arrived':Arrived}
    return render(request,'WaitingRoomMob.html',context)

def ShowNotifications(reuqest):
    try:
        notify=Notification.objects.filter(seen=False).order_by('date')[0]
        notify.seen=True
        notify.save()
        return HttpResponse(notify.notification)
    except:
        return HttpResponse("No_Notifications")

def addNotification(notification):
    DB=Notification()
    DB.notification=notification
    DB.save()

def ParentLogin(request):
    email=request.GET.get('us','')
    email.replace("%E2%80%8B","")
    password=request.GET.get('p','')
    print(email)
    print(password)
    try :
        user=Parent.objects.get(Email=email)
    except:
        return HttpResponse("No User Found")
    if(user.Password in password):
        return HttpResponse('true')
    return HttpResponse("User and Password Do Not Match")

def register(request):
        user=request.GET.get('us','')
        try :
            user=User.objects.get(Email=user)
            return HttpResponse("Username already Registered")
        except:
            DB=Parent()
            DB.Name=request.GET.get('us','')
            DB.Password=request.GET.get('p','')
            DB.Email=request.GET.get('no','')
            DB.save()
            return HttpResponse('Successfully Registered')

#Serial Data for API's
def Dashboard(reques):
    Data={'Teachers':8,'Students':200}
    JsonData=json.dumps(Data)
    return HttpResponse(JsonData)

def AssosiateChilds(request):
    _email=request.GET.get('us','')
    _parent=Parent.objects.get(Email=_email)
    Data=ParentAssosiate.objects.filter(parent=_parent)
    Guard=StudentGuard.objects.all()
    Arrived=GuardArrived.objects.all()
    context={'Data':Data,'Guards':Guard,'Arrived':Arrived}
    return render(request,'AssosiateChilds.html',context)


def ParentChildAttendance(request):
    _email=request.GET.get('us','')
    _parent=Parent.objects.get(Email=_email)
    ParentChildren=ParentAssosiate.objects.filter(parent=_parent)
    attendance=[]
    for children in ParentChildren:
        attendance.append(Attendance.objects.filter(student=children.child))
    context={'Attendance':attendance}
    return render(request,'assosiatechildattendance.html',context)


class userList(APIView):
    def get(self,request):
        Users=User.objects.all()
        serializer=UserSerializer(Users,many=True)
        return Response(serializer.data)

    def post(self):
        pass

class guardList(APIView):
    def get(self,request):
        Guards=Guardian.objects.all()
        serializer=GuardianSerializer(Guards,many=True)
        return Response(serializer.data)

    def post(self):
        pass

class studentList(APIView):
    def get(self,request):
        Students=StudentClass.objects.all()
        serializer=StudentSerializer(Students,many=True)
        return Response(serializer.data)

    def post(self):
        pass

class teacherList(APIView):
    def get(self,request):
        DATA=Teacher.objects.all()
        serializer=TeacherSerializer(DATA,many=True)
        return Response(serializer.data)

    def post(self):
        pass

class attendanceList(APIView):
    def get(self,request):
        DATA=Attendance.objects.all()
        serializer=AttendanceSerializer(DATA,many=True)
        return Response(serializer.data)

    def post(self):
        pass

class notificationList(APIView):
    def get(self,request):
        DATA=Notification.objects.all()
        serializer=NotificationSerializer(DATA,many=True)
        return Response(serializer.data)
    def post(self):
        pass
