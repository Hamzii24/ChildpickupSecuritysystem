from django.contrib import admin
from .models import *
admin.site.register(User)
admin.site.register(StudentClass)
admin.site.register(Guardian)
admin.site.register(Attendance)
admin.site.register(Teacher)
admin.site.register(Notification)
admin.site.register(GuardArrived)
admin.site.register(StudentGuard)
#admin.site.register(Parent)
admin.site.register(ParentAssosiate)
