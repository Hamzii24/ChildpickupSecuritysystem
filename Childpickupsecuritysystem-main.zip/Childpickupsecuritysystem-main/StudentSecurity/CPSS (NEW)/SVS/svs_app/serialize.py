from rest_framework import serializers
from .models import *

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['Name','Email','UserType']

class GuardianSerializer(serializers.ModelSerializer):
    Name=serializers.CharField(source='User.Name')
    Email=serializers.EmailField(source='User.Email')
    class Meta:
        model = Guardian
        fields = ['Name','Email','phone','id']

class StudentSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='User.Name')
    guard_name = serializers.CharField(source='Guard.User.Name')
    class Meta:
        model = StudentClass
        fields = ['User','Guard','Class','Section','RollNo','student_name','guard_name','id']

class TeacherSerializer(serializers.ModelSerializer):
    Name=serializers.CharField(source='User.Name')
    Email=serializers.EmailField(source='User.Email')
    class Meta:
        model = Teacher
        fields = ['Name','Email','Address','Class','id']

class AttendanceSerializer(serializers.ModelSerializer):
    Name=serializers.CharField(source='student.User.Name')
    Class=serializers.CharField(source='student.Class')
    Section=serializers.CharField(source='student.Section')
    class Meta:
        model = Attendance
        fields = ['Name','Section','date','Class']

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ['date','notification']
