from django.apps import AppConfig


class SvsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'svs_app'
