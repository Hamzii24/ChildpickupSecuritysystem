from django import forms
from django.contrib.admin.widgets import AdminSplitDateTime
from django.forms import ModelForm
from .models import *

class NotificationForm(ModelForm):
    notification=forms.CharField(label=" ADD Notification",max_length=100,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Enter  Notification'}))
    class Meta:
        model = Notification
        fields = ['notification']

        
class TeacherForm(forms.Form):
    Name=forms.CharField(label="",max_length=100,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Enter Name'}))
    Password=forms.CharField(label="",max_length=20,widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password','type':'Password'}))
    Confirmpassword=forms.CharField(label="",max_length=20,widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Confirm Password'}))
    Email=forms.EmailField(label="",max_length=100,widget=forms.EmailInput(attrs={'class':'form-control','placeholder':'Enter Your Email Address'}))
    Address=forms.CharField(label="",max_length=200,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Your Address'}))
    Class=forms.CharField(label="",max_length=200,widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Class'}))
